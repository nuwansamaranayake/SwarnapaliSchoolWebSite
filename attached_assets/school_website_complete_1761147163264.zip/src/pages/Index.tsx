import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import AcademicsSection from "@/components/AcademicsSection";
import GallerySection from "@/components/GallerySection";
import NewsSection from "@/components/NewsSection";
import SchoolIdentitySection from "@/components/SchoolIdentitySection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <main>
        <HeroSection />
        <AboutSection />
        <AcademicsSection />
        <SchoolIdentitySection />
        <GallerySection />
        <NewsSection />
      </main>
      <Footer />
    </div>
  );
};

export default Index;