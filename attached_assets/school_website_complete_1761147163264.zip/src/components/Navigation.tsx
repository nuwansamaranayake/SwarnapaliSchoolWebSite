import { useState } from "react";
import { Menu, X, GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import { cn } from "@/lib/utils";

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsOpen(false); // Close mobile menu after clicking
  };

  const academicSections = [
    { title: "Primary Section", href: "primary", description: "Grades 1-5" },
    { title: "Grade 6-7", href: "grade-6-7", description: "Middle School" },
    { title: "Grade 8-9", href: "grade-8-9", description: "Junior Secondary" },
    { title: "Grade 10-11", href: "grade-10-11", description: "Senior Secondary" },
    { title: "Grade 12-13", href: "grade-12-13", description: "Advanced Level" },
  ];

  const schoolIdentity = [
    { title: "School Anthem", href: "anthem", description: "Our school song" },
    { title: "School Uniform", href: "uniform", description: "Dress code guidelines" },
    { title: "School Buildings", href: "buildings", description: "Campus facilities" },
    { title: "Resources", href: "resources", description: "Learning materials" },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2 cursor-pointer" onClick={() => scrollToSection('hero')}>
            <GraduationCap className="h-8 w-8 text-primary" />
            <div className="flex flex-col">
              <span className="text-lg font-bold text-primary">Swarnapali Balika</span>
              <span className="text-xs text-muted-foreground">National School</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <NavigationMenu>
              <NavigationMenuList>
                <NavigationMenuItem>
                  <button
                    onClick={() => scrollToSection('hero')}
                    className="group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50"
                  >
                    Home
                  </button>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <NavigationMenuTrigger>Academics</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                      {academicSections.map((section) => (
                        <ListItem
                          key={section.title}
                          title={section.title}
                          onClick={() => scrollToSection(section.href)}
                        >
                          {section.description}
                        </ListItem>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <button
                    onClick={() => scrollToSection('gallery')}
                    className="group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50"
                  >
                    Gallery
                  </button>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <button
                    onClick={() => scrollToSection('about')}
                    className="group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50"
                  >
                    About
                  </button>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <NavigationMenuTrigger>School Identity</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                      {schoolIdentity.map((item) => (
                        <ListItem
                          key={item.title}
                          title={item.title}
                          onClick={() => scrollToSection(item.href)}
                        >
                          {item.description}
                        </ListItem>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>

            <Button 
              variant="default" 
              className="bg-gradient-to-r from-primary to-accent hover:from-primary/90 hover:to-accent/90"
              onClick={() => scrollToSection('contact')}
            >
              Contact Us
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Toggle menu"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 border-t">
              <button 
                onClick={() => scrollToSection('hero')} 
                className="block w-full text-left px-3 py-2 text-base font-medium hover:bg-accent rounded-md"
              >
                Home
              </button>
              <div className="px-3 py-2">
                <div className="text-sm font-medium text-muted-foreground mb-2">Academics</div>
                {academicSections.map((section) => (
                  <button
                    key={section.title}
                    onClick={() => scrollToSection(section.href)}
                    className="block w-full text-left px-3 py-1 text-sm hover:bg-accent rounded-md"
                  >
                    {section.title}
                  </button>
                ))}
              </div>
              <button 
                onClick={() => scrollToSection('gallery')} 
                className="block w-full text-left px-3 py-2 text-base font-medium hover:bg-accent rounded-md"
              >
                Gallery
              </button>
              <button 
                onClick={() => scrollToSection('about')} 
                className="block w-full text-left px-3 py-2 text-base font-medium hover:bg-accent rounded-md"
              >
                About
              </button>
              <div className="px-3 py-2">
                <div className="text-sm font-medium text-muted-foreground mb-2">School Identity</div>
                {schoolIdentity.map((item) => (
                  <button
                    key={item.title}
                    onClick={() => scrollToSection(item.href)}
                    className="block w-full text-left px-3 py-1 text-sm hover:bg-accent rounded-md"
                  >
                    {item.title}
                  </button>
                ))}
              </div>
              <div className="px-3 py-2">
                <Button 
                  className="w-full bg-gradient-to-r from-primary to-accent"
                  onClick={() => scrollToSection('contact')}
                >
                  Contact Us
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

const ListItem = ({ className, title, children, onClick, ...props }: any) => {
  return (
    <li>
      <button
        onClick={onClick}
        className={cn(
          "block w-full text-left select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
          className
        )}
        {...props}
      >
        <div className="text-sm font-medium leading-none">{title}</div>
        <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
          {children}
        </p>
      </button>
    </li>
  );
};

export default Navigation;