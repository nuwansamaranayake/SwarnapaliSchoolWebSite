import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, Users, Trophy } from "lucide-react";

const AboutSection = () => {
  const milestones = [
    { year: "1876", event: "Founded by French nuns as a mixed school" },
    { year: "1986", event: "Renamed to Swarnapali Balika Maha Vidyalaya" },
    { year: "1993", event: "Designated as National School on May 25th" },
    { year: "2000", event: "Reached 4067 students with 175 teachers" },
  ];

  const administrativeStaff = [
    { position: "Principal", name: "Mrs. [Principal Name]" },
    { position: "Deputy Principal (Administration)", name: "Mrs. [Deputy Principal]" },
    { position: "Deputy Principal (Primary)", name: "Mrs. [Deputy Principal]" },
    { position: "Deputy Principal (Co-curricular)", name: "Mrs. [Deputy Principal]" },
    { position: "Assistant Principal (Administration)", name: "Mrs. [Assistant Principal]" },
  ];

  return (
    <section id="about" className="py-20 bg-gradient-subtle">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4">
            <Calendar className="w-4 h-4 mr-2" />
            Established 1876
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">
            About Our School
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A legacy of educational excellence spanning over 147 years, 
            shaping generations of empowered young women in Sri Lanka.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* School History */}
          <div className="space-y-8">
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Trophy className="w-6 h-6 mr-3 text-secondary" />
                  Our Heritage
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground leading-relaxed">
                  A/Swarnapali Balika Maha Vidyalaya stands as a beacon of educational 
                  excellence in Anuradhapura, Sri Lanka. Founded in 1876 by French nuns, 
                  our institution has evolved from a small mixed school to become one of 
                  the leading girls' schools in the North Central Province.
                </p>
                
                <p className="text-muted-foreground leading-relaxed">
                  Our journey through various transformations reflects our commitment to 
                  adapting with the times while maintaining our core values. From introducing 
                  new academic streams including Arts, Commerce, Science, and Mathematics to 
                  expanding our infrastructure, we have consistently grown to meet the 
                  educational needs of our community.
                </p>

                <div className="flex items-center space-x-4 p-4 bg-muted rounded-lg">
                  <MapPin className="w-5 h-5 text-primary" />
                  <div>
                    <div className="font-semibold">Location</div>
                    <div className="text-sm text-muted-foreground">Anuradhapura, North Central Province, Sri Lanka</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* School Vision */}
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle className="text-2xl text-primary">Our Vision</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  To develop well-rounded "Swarnapali" individuals equipped with knowledge, 
                  character, communication skills, and physical health, capable of facing 
                  any challenge with confidence and grace.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Timeline and Stats */}
          <div className="space-y-8">
            {/* Key Milestones */}
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Calendar className="w-6 h-6 mr-3 text-accent" />
                  Key Milestones
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {milestones.map((milestone, index) => (
                    <div key={index} className="flex items-start space-x-4">
                      <div className="flex-shrink-0 w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                        <span className="text-sm font-bold text-primary">{milestone.year}</span>
                      </div>
                      <div className="flex-1 pt-2">
                        <p className="text-muted-foreground">{milestone.event}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Current Statistics */}
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <Users className="w-6 h-6 mr-3 text-secondary" />
                  Current Statistics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center p-4 bg-primary/5 rounded-lg">
                    <div className="text-3xl font-bold text-primary">4000+</div>
                    <div className="text-sm text-muted-foreground">Students</div>
                  </div>
                  <div className="text-center p-4 bg-secondary/5 rounded-lg">
                    <div className="text-3xl font-bold text-secondary">175+</div>
                    <div className="text-sm text-muted-foreground">Teachers</div>
                  </div>
                  <div className="text-center p-4 bg-accent/5 rounded-lg">
                    <div className="text-3xl font-bold text-accent">5</div>
                    <div className="text-sm text-muted-foreground">Academic Streams</div>
                  </div>
                  <div className="text-center p-4 bg-primary/5 rounded-lg">
                    <div className="text-3xl font-bold text-primary">147</div>
                    <div className="text-sm text-muted-foreground">Years of Service</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Administrative Staff */}
        <Card className="elegant-shadow">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Administrative Staff</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {administrativeStaff.map((staff, index) => (
                <div key={index} className="text-center p-4 bg-muted/50 rounded-lg">
                  <div className="font-semibold text-primary mb-2">{staff.position}</div>
                  <div className="text-muted-foreground">{staff.name}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default AboutSection;