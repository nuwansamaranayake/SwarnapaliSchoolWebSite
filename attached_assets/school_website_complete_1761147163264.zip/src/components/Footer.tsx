import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { 
  GraduationCap, 
  MapPin, 
  Phone, 
  Mail, 
  Facebook, 
  Twitter, 
  Instagram, 
  Youtube,
  ExternalLink,
  Heart
} from "lucide-react";

const Footer = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const quickLinks = [
    { title: "Home", href: "hero" },
    { title: "About Us", href: "about" },
    { title: "Academics", href: "academics" },
    { title: "Gallery", href: "gallery" },
    { title: "Contact", href: "contact" }
  ];

  const academicLinks = [
    { title: "Primary Section", href: "primary" },
    { title: "Grade 6-7", href: "grade-6-7" },
    { title: "Grade 8-9", href: "grade-8-9" },
    { title: "Grade 10-11", href: "grade-10-11" },
    { title: "Grade 12-13", href: "grade-12-13" }
  ];

  const resourceLinks = [
    { title: "Learning Management System", href: "lms" },
    { title: "Student Portal", href: "portal" },
    { title: "Download Materials", href: "downloads" },
    { title: "Scholarships", href: "scholarships" },
    { title: "School Calendar", href: "calendar" }
  ];

  return (
    <footer className="bg-primary text-primary-foreground">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8">
          {/* School Information */}
          <div className="space-y-6">
            <div 
              className="flex items-center space-x-2 cursor-pointer" 
              onClick={() => scrollToSection('hero')}
            >
              <GraduationCap className="h-8 w-8 text-secondary" />
              <div>
                <div className="text-xl font-bold">Swarnapali Balika</div>
                <div className="text-sm opacity-90">Maha Vidyalaya</div>
              </div>
            </div>
            
            <p className="text-sm opacity-90 leading-relaxed">
              A leading girls' school in Sri Lanka since 1876, dedicated to nurturing 
              excellence in education and developing well-rounded individuals with 
              knowledge, character, and values.
            </p>

            <div className="space-y-3" id="contact">
              <div className="flex items-center space-x-3">
                <MapPin className="h-4 w-4 text-secondary flex-shrink-0" />
                <span className="text-sm">Anuradhapura, North Central Province, Sri Lanka</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-secondary flex-shrink-0" />
                <span className="text-sm">+94 2 5223 4225</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-secondary flex-shrink-0" />
                <span className="text-sm">info@swarnapalibalika.lk</span>
              </div>
            </div>

            {/* Social Media Links */}
            <div className="flex space-x-3">
              <Button size="icon" variant="secondary" className="h-8 w-8">
                <Facebook className="h-4 w-4" />
              </Button>
              <Button size="icon" variant="secondary" className="h-8 w-8">
                <Twitter className="h-4 w-4" />
              </Button>
              <Button size="icon" variant="secondary" className="h-8 w-8">
                <Instagram className="h-4 w-4" />
              </Button>
              <Button size="icon" variant="secondary" className="h-8 w-8">
                <Youtube className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <button 
                    onClick={() => scrollToSection(link.href)}
                    className="text-sm opacity-90 hover:opacity-100 hover:text-secondary smooth-transition flex items-center"
                  >
                    {link.title}
                    <ExternalLink className="h-3 w-3 ml-1 opacity-50" />
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Academic Sections */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Academic Sections</h3>
            <ul className="space-y-3">
              {academicLinks.map((link, index) => (
                <li key={index}>
                  <button 
                    onClick={() => scrollToSection(link.href)}
                    className="text-sm opacity-90 hover:opacity-100 hover:text-secondary smooth-transition"
                  >
                    {link.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources & Newsletter */}
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-6">Resources</h3>
              <ul className="space-y-3">
                {resourceLinks.slice(0, 3).map((link, index) => (
                  <li key={index}>
                    <button 
                      onClick={() => scrollToSection(link.href)}
                      className="text-sm opacity-90 hover:opacity-100 hover:text-secondary smooth-transition"
                    >
                      {link.title}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Newsletter Signup */}
            <div>
              <h4 className="font-semibold mb-3">Stay Updated</h4>
              <p className="text-sm opacity-90 mb-4">
                Subscribe to receive school news and updates
              </p>
              <div className="flex space-x-2">
                <Input 
                  placeholder="Enter your email"
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/60"
                />
                <Button variant="secondary" size="sm">
                  Subscribe
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Separator className="bg-white/20" />

      {/* Bottom Footer */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-sm opacity-90">
            © 2024 A/Swarnapali Balika Maha Vidyalaya. All rights reserved.
          </div>
          
          <div className="flex items-center space-x-6 text-sm opacity-90">
            <button onClick={() => scrollToSection('privacy')} className="hover:opacity-100 smooth-transition">
              Privacy Policy
            </button>
            <button onClick={() => scrollToSection('terms')} className="hover:opacity-100 smooth-transition">
              Terms of Service
            </button>
            <button onClick={() => scrollToSection('sitemap')} className="hover:opacity-100 smooth-transition">
              Sitemap
            </button>
          </div>

          <div className="flex items-center space-x-1 text-sm opacity-90">
            <span>Made with</span>
            <Heart className="h-4 w-4 text-red-400 fill-current" />
            <span>for education</span>
          </div>
        </div>
      </div>

      {/* School Motto */}
      <div className="bg-secondary text-secondary-foreground py-4">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm font-medium">
            "Developing knowledge, character, communication, and health - Creating confident Swarnapali individuals"
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;