import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bell, Calendar, Download, ExternalLink, Megaphone, FileText, Award, Users } from "lucide-react";

const NewsSection = () => {
  const latestNews = [
    {
      id: 1,
      title: "2024 A/L Online Application Now Available",
      content: "Students can now download and submit their Advanced Level applications online. All necessary forms and guidelines are available for download.",
      date: "2024-01-15",
      category: "Academic",
      priority: "high",
      hasDownload: true
    },
    {
      id: 2,
      title: "Outstanding 2023 O/L Results Announced",
      content: "Swarnapali Balika achieves exceptional results in 2023 Ordinary Level examinations, maintaining our position as the leading girls' school in the province.",
      date: "2024-01-10",
      category: "Achievement",
      priority: "high",
      hasImages: true
    },
    {
      id: 3,
      title: "New Learning Management System Launch",
      content: "We are excited to introduce our new digital learning platform to enhance online education and resource sharing for all students and teachers.",
      date: "2024-01-05",
      category: "Technology",
      priority: "medium"
    },
    {
      id: 4,
      title: "Presidential Fund Scholarship Applications Open",
      content: "Eligible students can now apply for the Presidential Fund scholarships. Visit the official website for more information and application procedures.",
      date: "2023-12-20",
      category: "Scholarship",
      priority: "medium",
      hasExternalLink: true
    }
  ];

  const announcements = [
    {
      title: "School Reopening Schedule",
      content: "New academic year begins on January 22, 2024. All students must report by 7:30 AM.",
      date: "2024-01-18",
      type: "urgent"
    },
    {
      title: "Parent-Teacher Meeting",
      content: "Monthly parent-teacher conference scheduled for January 25, 2024, from 2:00 PM to 5:00 PM.",
      date: "2024-01-16",
      type: "meeting"
    },
    {
      title: "Sports Day Preparations",
      content: "Annual sports meet preparations begin next week. All students encouraged to participate.",
      date: "2024-01-14",
      type: "event"
    }
  ];

  const quickLinks = [
    {
      title: "Download Study Materials",
      description: "Access all learning resources and study guides",
      icon: Download,
      action: "Download"
    },
    {
      title: "Scholarship Information",
      description: "Learn about available scholarships and application process",
      icon: Award,
      action: "Learn More"
    },
    {
      title: "Student Portal",
      description: "Access grades, assignments, and school updates",
      icon: Users,
      action: "Access Portal"
    },
    {
      title: "Contact Administration",
      description: "Get in touch with school administration",
      icon: FileText,
      action: "Contact"
    }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-500";
      case "medium": return "bg-yellow-500";
      default: return "bg-blue-500";
    }
  };

  const getAnnouncementIcon = (type: string) => {
    switch (type) {
      case "urgent": return <Bell className="w-4 h-4" />;
      case "meeting": return <Users className="w-4 h-4" />;
      case "event": return <Calendar className="w-4 h-4" />;
      default: return <Megaphone className="w-4 h-4" />;
    }
  };

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4">
            <Bell className="w-4 h-4 mr-2" />
            Latest Updates
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">
            News & Announcements
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Stay informed with the latest news, announcements, and important updates 
            from Swarnapali Balika Maha Vidyalaya.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Latest News */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-primary">Latest News</h3>
              <Button variant="outline">View All News</Button>
            </div>

            {latestNews.map((news) => (
              <Card key={news.id} className="elegant-shadow hover:shadow-lg smooth-transition">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <div className={`w-2 h-2 rounded-full ${getPriorityColor(news.priority)}`} />
                        <Badge variant="secondary">{news.category}</Badge>
                        <span className="text-sm text-muted-foreground">
                          {new Date(news.date).toLocaleDateString()}
                        </span>
                      </div>
                      <CardTitle className="text-xl hover:text-primary smooth-transition cursor-pointer">
                        {news.title}
                      </CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    {news.content}
                  </p>
                  
                  <div className="flex flex-wrap gap-2">
                    {news.hasDownload && (
                      <Button size="sm" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    )}
                    {news.hasImages && (
                      <Button size="sm" variant="outline">
                        <Calendar className="w-4 h-4 mr-2" />
                        View Images
                      </Button>
                    )}
                    {news.hasExternalLink && (
                      <Button size="sm" variant="outline">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        External Link
                      </Button>
                    )}
                    <Button size="sm" className="ml-auto">
                      Read More
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Announcements */}
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Megaphone className="w-5 h-5 mr-2 text-primary" />
                  Announcements
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {announcements.map((announcement, index) => (
                  <div key={index} className="p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      {getAnnouncementIcon(announcement.type)}
                      <span className="text-sm font-medium">{announcement.title}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      {announcement.content}
                    </p>
                    <span className="text-xs text-muted-foreground">
                      {new Date(announcement.date).toLocaleDateString()}
                    </span>
                  </div>
                ))}
                <Button variant="outline" className="w-full">
                  View All Announcements
                </Button>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle>Quick Links</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {quickLinks.map((link, index) => {
                  const IconComponent = link.icon;
                  return (
                    <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/50 smooth-transition cursor-pointer">
                      <div className="flex items-center space-x-3">
                        <IconComponent className="w-5 h-5 text-primary" />
                        <div>
                          <div className="font-medium text-sm">{link.title}</div>
                          <div className="text-xs text-muted-foreground">{link.description}</div>
                        </div>
                      </div>
                      <Button size="sm" variant="ghost">
                        {link.action}
                      </Button>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card className="elegant-shadow bg-primary text-primary-foreground">
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <div className="font-medium">Phone</div>
                  <div className="text-sm opacity-90">+94 2 5223 4225</div>
                </div>
                <div>
                  <div className="font-medium">Email</div>
                  <div className="text-sm opacity-90">info@swarnapalibalika.lk</div>
                </div>
                <div>
                  <div className="font-medium">Address</div>
                  <div className="text-sm opacity-90">Anuradhapura, North Central Province, Sri Lanka</div>
                </div>
                <Button variant="secondary" className="w-full mt-4">
                  Get Directions
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NewsSection;