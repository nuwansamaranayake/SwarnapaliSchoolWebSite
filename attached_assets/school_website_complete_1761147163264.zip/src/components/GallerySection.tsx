import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Camera, Calendar, Users, Award, Music, Palette, ChevronLeft, ChevronRight } from "lucide-react";

const GallerySection = () => {
  const [selectedCategory, setSelectedCategory] = useState("all");

  const categories = [
    { id: "all", label: "All Photos", icon: Camera },
    { id: "events", label: "School Events", icon: Calendar },
    { id: "academic", label: "Academic Activities", icon: Award },
    { id: "cultural", label: "Cultural Programs", icon: Music },
    { id: "sports", label: "Sports & Recreation", icon: Users },
    { id: "arts", label: "Arts & Crafts", icon: Palette },
  ];

  const galleryItems = [
    {
      id: 1,
      title: "Trilingual Day Celebration",
      category: "cultural",
      image: "/images/school_images_1.jpeg",
      description: "Students celebrating our annual Trilingual Day with cultural performances and language exhibitions.",
      date: "2023"
    },
    {
      id: 2,
      title: "School Campus View",
      category: "academic",
      image: "/images/school_images_2.jpeg",
      description: "Beautiful view of our modern school campus with state-of-the-art facilities.",
      date: "2023"
    },
    {
      id: 3,
      title: "Student Assembly",
      category: "events",
      image: "/images/school_images_3.jpeg",
      description: "Weekly student assembly showcasing achievements and announcements.",
      date: "2023"
    },
    {
      id: 4,
      title: "Classroom Learning",
      category: "academic",
      image: "/images/school_images_4.jpeg",
      description: "Interactive classroom sessions with modern teaching methodologies.",
      date: "2023"
    },
    {
      id: 5,
      title: "School Building",
      category: "academic",
      image: "/images/school_images_5.jpeg",
      description: "Our historic school building representing 147 years of educational excellence.",
      date: "2023"
    },
    {
      id: 6,
      title: "Teaching Excellence",
      category: "academic",
      image: "/images/school_images_6.jpeg",
      description: "Dedicated teachers providing quality education and mentorship.",
      date: "2023"
    }
  ];

  const filteredItems = selectedCategory === "all" 
    ? galleryItems 
    : galleryItems.filter(item => item.category === selectedCategory);

  return (
    <section id="gallery" className="py-20 bg-gradient-subtle">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4">
            <Camera className="w-4 h-4 mr-2" />
            School Gallery
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">
            Capturing Memories
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Explore the vibrant life at Swarnapali Balika through our photo gallery, 
            showcasing academic excellence, cultural richness, and student achievements.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => {
            const IconComponent = category.icon;
            return (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.id)}
                className="smooth-transition"
              >
                <IconComponent className="w-4 h-4 mr-2" />
                {category.label}
              </Button>
            );
          })}
        </div>

        {/* Gallery Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {filteredItems.map((item) => (
            <Dialog key={item.id}>
              <DialogTrigger asChild>
                <Card className="group cursor-pointer overflow-hidden elegant-shadow hover:shadow-xl smooth-transition">
                  <div className="relative overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-64 object-cover group-hover:scale-105 smooth-transition"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 smooth-transition" />
                    <div className="absolute top-4 right-4">
                      <Badge variant="secondary" className="bg-white/90">
                        {item.date}
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg mb-2 group-hover:text-primary smooth-transition">
                      {item.title}
                    </h3>
                    <p className="text-muted-foreground text-sm line-clamp-2">
                      {item.description}
                    </p>
                  </CardContent>
                </Card>
              </DialogTrigger>
              <DialogContent className="max-w-4xl">
                <div className="space-y-4">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-auto rounded-lg"
                  />
                  <div>
                    <h3 className="text-2xl font-bold mb-2">{item.title}</h3>
                    <p className="text-muted-foreground">{item.description}</p>
                    <Badge variant="outline" className="mt-2">
                      {item.date}
                    </Badge>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          ))}
        </div>

        {/* Featured Events */}
        <div className="bg-white rounded-2xl p-8 elegant-shadow">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold text-primary mb-4">Featured Events</h3>
            <p className="text-muted-foreground">
              Highlights from our most memorable school events and celebrations
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center elegant-shadow">
              <CardContent className="p-6">
                <Music className="w-12 h-12 text-primary mx-auto mb-4" />
                <h4 className="font-semibold mb-2">Trilingual Day</h4>
                <p className="text-sm text-muted-foreground">
                  Celebrating linguistic diversity and cultural heritage
                </p>
              </CardContent>
            </Card>

            <Card className="text-center elegant-shadow">
              <CardContent className="p-6">
                <Award className="w-12 h-12 text-secondary mx-auto mb-4" />
                <h4 className="font-semibold mb-2">Prize Giving</h4>
                <p className="text-sm text-muted-foreground">
                  Recognizing academic and extracurricular achievements
                </p>
              </CardContent>
            </Card>

            <Card className="text-center elegant-shadow">
              <CardContent className="p-6">
                <Users className="w-12 h-12 text-accent mx-auto mb-4" />
                <h4 className="font-semibold mb-2">Sports Meet</h4>
                <p className="text-sm text-muted-foreground">
                  Annual athletics and sports competitions
                </p>
              </CardContent>
            </Card>

            <Card className="text-center elegant-shadow">
              <CardContent className="p-6">
                <Palette className="w-12 h-12 text-primary mx-auto mb-4" />
                <h4 className="font-semibold mb-2">Arts Festival</h4>
                <p className="text-sm text-muted-foreground">
                  Showcasing creativity and artistic talents
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-8">
            <Button size="lg" className="bg-gradient-to-r from-primary to-accent">
              View More Photos
              <Camera className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GallerySection;