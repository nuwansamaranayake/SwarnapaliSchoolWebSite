import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, Users, Music, Building, FileText } from "lucide-react";

const SchoolIdentitySection = () => {
  return (
    <>
      {/* Academic Grade Sections */}
      <section id="primary" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-4">
              <BookOpen className="w-4 h-4 mr-2" />
              Primary Section
            </Badge>
            <h2 className="text-4xl font-bold text-primary mb-6">Primary Section (Grades 1-5)</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Foundation years focusing on basic literacy, numeracy, and character development 
              with a nurturing environment for young learners.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="elegant-shadow">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-3">Curriculum Focus</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Bilingual Education (Sinhala & English)</li>
                  <li>• Basic Mathematics & Science</li>
                  <li>• Creative Arts & Music</li>
                  <li>• Physical Education</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-3">Student Statistics</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Total Students:</span>
                    <span className="font-semibold">800+</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Teachers:</span>
                    <span className="font-semibold">35+</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Classes:</span>
                    <span className="font-semibold">Grade 1-5</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-3">Special Programs</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Character Building Activities</li>
                  <li>• Creative Learning Methods</li>
                  <li>• Sports & Cultural Programs</li>
                  <li>• Parent Engagement Programs</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section id="grade-6-7" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-4">
              <Users className="w-4 h-4 mr-2" />
              Grade 6-7 Section
            </Badge>
            <h2 className="text-4xl font-bold text-primary mb-6">Grade 6-7 Section (Middle School)</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Transitional phase preparing students for secondary education with enhanced curriculum 
              and leadership development opportunities.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-8">
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle>Section In-Charge</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center p-6 bg-muted/50 rounded-lg">
                  <h3 className="text-lg font-semibold mb-2">Mrs. K.A Ramya Kularathne</h3>
                  <p className="text-muted-foreground">In Charge of Grade 6/7 Classes</p>
                </div>
                
                <div className="mt-6 grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-primary/5 rounded-lg">
                    <div className="text-2xl font-bold text-primary">600+</div>
                    <div className="text-sm text-muted-foreground">Students</div>
                  </div>
                  <div className="text-center p-4 bg-secondary/5 rounded-lg">
                    <div className="text-2xl font-bold text-secondary">25+</div>
                    <div className="text-sm text-muted-foreground">Teachers</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle>Key Features</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>Subject Specialization Introduction</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-secondary rounded-full"></div>
                    <span>Project-Based Learning</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-accent rounded-full"></div>
                    <span>Leadership Training Programs</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>Cultural Activities & Events</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section id="grade-8-9" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-4">
              <BookOpen className="w-4 h-4 mr-2" />
              Grade 8-9 Section
            </Badge>
            <h2 className="text-4xl font-bold text-primary mb-6">Grade 8-9 Section (Junior Secondary)</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Critical years for academic foundation building and O/L preparation with 
              comprehensive subject coverage and skill development.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-8">
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle>Academic Focus</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center space-x-3">
                    <Badge variant="secondary">Core</Badge>
                    <span>O/L Preparation Programs</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Badge variant="secondary">Science</Badge>
                    <span>Advanced Science Laboratory Work</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Badge variant="secondary">Tech</Badge>
                    <span>Computer Studies & IT Skills</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Badge variant="secondary">Lang</Badge>
                    <span>Language Development Programs</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle>Section Leadership</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center p-6 bg-muted/50 rounded-lg mb-4">
                  <h3 className="text-lg font-semibold mb-2">Mrs. K.A Ramya Kularathne</h3>
                  <p className="text-muted-foreground">In Charge of Grade 8 & 9 Classes</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-primary/5 rounded">
                    <div className="font-bold text-primary">700+</div>
                    <div className="text-xs text-muted-foreground">Students</div>
                  </div>
                  <div className="text-center p-3 bg-secondary/5 rounded">
                    <div className="font-bold text-secondary">30+</div>
                    <div className="text-xs text-muted-foreground">Teachers</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section id="grade-10-11" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-4">
              <Users className="w-4 h-4 mr-2" />
              Grade 10-11 Section
            </Badge>
            <h2 className="text-4xl font-bold text-primary mb-6">Grade 10-11 Section (Senior Secondary)</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Intensive O/L preparation and career guidance for future academic paths 
              with comprehensive support systems.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle className="text-center">O/L Excellence</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">95%+</div>
                <p className="text-muted-foreground">Pass Rate</p>
                <p className="text-sm mt-2">Outstanding O/L results with comprehensive preparation programs</p>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle className="text-center">Career Guidance</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="text-3xl font-bold text-secondary mb-2">100%</div>
                <p className="text-muted-foreground">Coverage</p>
                <p className="text-sm mt-2">Comprehensive career counseling and stream selection guidance</p>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle className="text-center">University Prep</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="text-3xl font-bold text-accent mb-2">85%+</div>
                <p className="text-muted-foreground">Success Rate</p>
                <p className="text-sm mt-2">Students successfully entering university programs</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section id="grade-12-13" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-4">
              <BookOpen className="w-4 h-4 mr-2" />
              Grade 12-13 Section
            </Badge>
            <h2 className="text-4xl font-bold text-primary mb-6">Grade 12-13 Section (Advanced Level)</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Specialized streams preparing students for university entrance and careers 
              with expert faculty and modern facilities.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle className="text-center text-lg">Arts Stream</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Literature & Languages</li>
                  <li>• History & Geography</li>
                  <li>• Political Science</li>
                  <li>• Economics</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle className="text-center text-lg">Commerce Stream</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Accounting</li>
                  <li>• Business Studies</li>
                  <li>• Economics</li>
                  <li>• Statistics</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle className="text-center text-lg">Science Stream</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Physics</li>
                  <li>• Chemistry</li>
                  <li>• Biology</li>
                  <li>• Mathematics</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle className="text-center text-lg">Mathematics Stream</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Pure Mathematics</li>
                  <li>• Applied Mathematics</li>
                  <li>• Physics</li>
                  <li>• Chemistry</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* School Identity Sections */}
      <section id="anthem" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-4">
              <Music className="w-4 h-4 mr-2" />
              School Identity
            </Badge>
            <h2 className="text-4xl font-bold text-primary mb-6">School Anthem</h2>
          </div>
          
          <Card className="max-w-4xl mx-auto elegant-shadow">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-semibold mb-4">Swarnapali Balika School Song</h3>
                <p className="text-muted-foreground">Our school anthem represents our values, heritage, and aspirations</p>
              </div>
              
              <div className="bg-muted/30 p-6 rounded-lg">
                <p className="text-center text-muted-foreground italic">
                  School anthem lyrics and musical notation would be displayed here, 
                  celebrating our school's heritage and values of knowledge, character, 
                  communication, and health.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section id="uniform" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-primary mb-6">School Uniform</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Our school uniform represents unity, discipline, and pride in our institution
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle>Primary Section (Grades 1-5)</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li>• White blouse with school badge</li>
                  <li>• Navy blue pinafore/skirt</li>
                  <li>• White socks and black shoes</li>
                  <li>• School tie (navy and gold)</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle>Secondary Section (Grades 6-11)</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li>• White shirt with school emblem</li>
                  <li>• Navy blue skirt (knee-length)</li>
                  <li>• School belt and tie</li>
                  <li>• Black leather shoes</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle>Advanced Level (Grades 12-13)</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li>• White blouse with badges</li>
                  <li>• Navy blue formal skirt</li>
                  <li>• Prefect badges (if applicable)</li>
                  <li>• Formal black shoes</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section id="buildings" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-4">
              <Building className="w-4 h-4 mr-2" />
              Infrastructure
            </Badge>
            <h2 className="text-4xl font-bold text-primary mb-6">School Buildings & Facilities</h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="elegant-shadow">
              <CardContent className="p-6">
                <Building className="w-12 h-12 text-primary mb-4" />
                <h3 className="text-lg font-semibold mb-3">Main Academic Block</h3>
                <p className="text-muted-foreground">Modern classrooms equipped with latest teaching aids and technology</p>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardContent className="p-6">
                <BookOpen className="w-12 h-12 text-secondary mb-4" />
                <h3 className="text-lg font-semibold mb-3">Library & Resource Center</h3>
                <p className="text-muted-foreground">Comprehensive collection of books, digital resources, and study spaces</p>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardContent className="p-6">
                <Users className="w-12 h-12 text-accent mb-4" />
                <h3 className="text-lg font-semibold mb-3">Science Laboratories</h3>
                <p className="text-muted-foreground">Well-equipped labs for Physics, Chemistry, Biology, and Computer Science</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section id="resources" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-4">
              <FileText className="w-4 h-4 mr-2" />
              Learning Resources
            </Badge>
            <h2 className="text-4xl font-bold text-primary mb-6">School Resources</h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle>Digital Learning Platform</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Access our comprehensive Learning Management System with study materials, 
                  assignments, and interactive content.
                </p>
                <Button className="w-full">Access LMS</Button>
              </CardContent>
            </Card>
            
            <Card className="elegant-shadow">
              <CardHeader>
                <CardTitle>Study Materials & Downloads</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Download past papers, study guides, and supplementary materials 
                  for all grade levels and subjects.
                </p>
                <Button variant="outline" className="w-full">Download Resources</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </>
  );
};

export default SchoolIdentitySection;