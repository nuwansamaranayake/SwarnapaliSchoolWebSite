import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, Users, GraduationCap, Award, ChevronRight } from "lucide-react";

const AcademicsSection = () => {
  const academicSections = [
    {
      id: "primary",
      title: "Primary Section",
      grades: "Grades 1-5",
      description: "Foundation years focusing on basic literacy, numeracy, and character development.",
      icon: BookOpen,
      color: "bg-blue-500",
      students: "800+",
      teachers: "35+",
      features: ["Bilingual Education", "Creative Learning", "Character Building", "Sports & Arts"]
    },
    {
      id: "grade-6-7",
      title: "Grade 6-7 Section",
      grades: "Middle School",
      description: "Transitional phase preparing students for secondary education with enhanced curriculum.",
      icon: Users,
      color: "bg-green-500",
      students: "600+",
      teachers: "25+",
      inCharge: "Mrs. K.A Ramya Kularathne",
      features: ["Subject Specialization", "Project-Based Learning", "Leadership Training", "Cultural Activities"]
    },
    {
      id: "grade-8-9",
      title: "Grade 8-9 Section",
      grades: "Junior Secondary",
      description: "Critical years for academic foundation building and O/L preparation.",
      icon: GraduationCap,
      color: "bg-purple-500",
      students: "700+",
      teachers: "30+",
      inCharge: "Mrs. K.A Ramya Kularathne",
      features: ["O/L Preparation", "Science Labs", "Computer Studies", "Language Development"]
    },
    {
      id: "grade-10-11",
      title: "Grade 10-11 Section",
      grades: "Senior Secondary",
      description: "Intensive O/L preparation and career guidance for future academic paths.",
      icon: Award,
      color: "bg-orange-500",
      students: "800+",
      teachers: "35+",
      inCharge: "Mrs. K.A Ramya Kularathne",
      features: ["O/L Excellence", "Career Counseling", "Stream Selection", "University Prep"]
    },
    {
      id: "grade-12-13",
      title: "Grade 12-13 Section",
      grades: "Advanced Level",
      description: "Specialized streams preparing students for university entrance and careers.",
      icon: GraduationCap,
      color: "bg-red-500",
      students: "500+",
      teachers: "40+",
      features: ["Arts Stream", "Commerce Stream", "Science Stream", "Mathematics Stream"]
    }
  ];

  const achievements = [
    {
      title: "2023 O/L Results",
      description: "Outstanding performance with highest pass rates in the province",
      badge: "Excellence"
    },
    {
      title: "A/L Success Rate",
      description: "Consistent university entrance achievements across all streams",
      badge: "Achievement"
    },
    {
      title: "Provincial Rankings",
      description: "Top-ranked girls' school in North Central Province",
      badge: "Recognition"
    }
  ];

  return (
    <section id="academics" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4">
            <BookOpen className="w-4 h-4 mr-2" />
            Academic Excellence
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">
            Academic Sections
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive education from primary to advanced levels, 
            nurturing academic excellence and personal growth at every stage.
          </p>
        </div>

        {/* Academic Sections Grid */}
        <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-8 mb-16">
          {academicSections.map((section, index) => {
            const IconComponent = section.icon;
            return (
              <Card key={section.id} className="elegant-shadow hover:shadow-lg smooth-transition group">
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-lg ${section.color} text-white`}>
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <Badge variant="secondary">{section.grades}</Badge>
                  </div>
                  <CardTitle className="text-xl group-hover:text-primary smooth-transition">
                    {section.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">
                    {section.description}
                  </p>

                  {section.inCharge && (
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <div className="text-sm font-medium">Section In-Charge</div>
                      <div className="text-sm text-muted-foreground">{section.inCharge}</div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-2 bg-primary/5 rounded">
                      <div className="font-bold text-primary">{section.students}</div>
                      <div className="text-xs text-muted-foreground">Students</div>
                    </div>
                    <div className="text-center p-2 bg-secondary/5 rounded">
                      <div className="font-bold text-secondary">{section.teachers}</div>
                      <div className="text-xs text-muted-foreground">Teachers</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium">Key Features:</div>
                    <div className="flex flex-wrap gap-1">
                      {section.features.map((feature, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Button 
                    variant="ghost" 
                    className="w-full group-hover:bg-primary group-hover:text-primary-foreground smooth-transition"
                  >
                    Learn More
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Academic Achievements */}
        <div className="bg-muted/30 rounded-2xl p-8">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold text-primary mb-4">Academic Achievements</h3>
            <p className="text-muted-foreground">
              Celebrating our students' outstanding performance and recognition
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {achievements.map((achievement, index) => (
              <Card key={index} className="text-center elegant-shadow">
                <CardContent className="p-6">
                  <Badge className="mb-4" variant="secondary">
                    {achievement.badge}
                  </Badge>
                  <h4 className="text-lg font-semibold mb-2">{achievement.title}</h4>
                  <p className="text-muted-foreground text-sm">{achievement.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-8">
            <Button size="lg" className="bg-gradient-to-r from-primary to-accent">
              View All Achievements
              <Award className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AcademicsSection;